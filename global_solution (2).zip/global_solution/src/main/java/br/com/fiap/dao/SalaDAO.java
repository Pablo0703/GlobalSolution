package br.com.fiap.dao;

import br.com.fiap.to.SalaTO;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class SalaDAO extends Repository {
    public ArrayList<SalaTO> findAll() {
        ArrayList<SalaTO> salas = new ArrayList<SalaTO>();
        String sql = "SELECT * FROM T_GS_SALA order by idSala";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    SalaTO sala = new SalaTO();
                    sala.setIdSala(rs.getLong("id_sala"));
                    sala.setTipo(rs.getString("tipo"));
                    sala.setLocalizacao(rs.getString("localizacao"));
                    sala.setConsumoEnergia(rs.getDouble("consumo_energia"));
                    salas.add(sala);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return salas;
    }

    public SalaTO findById(Long id) {
        SalaTO sala = new SalaTO();
        String sql = "SELECT * FROM T_GS_SALA WHERE id_sala = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
                sala.setIdSala(rs.getLong("id_sala"));
                sala.setTipo(rs.getString("tipo"));
                sala.setLocalizacao(rs.getString("localizacao"));
                sala.setConsumoEnergia(rs.getDouble("consumo_energia"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return sala;
    }

    public SalaTO save(SalaTO sala) {
        String sql = "insert into T_GS_SALA (tipo, localizacao, consumo_energia) values(?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, sala.getTipo());
            ps.setString(2, sala.getLocalizacao());
            ps.setDouble(3, sala.getConsumoEnergia());
            if (ps.executeUpdate() > 0) {
                return sala;
            }
        } catch (SQLException e) {
            System.out.println("erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete (Long idSala) {
        String sql = "delete from T_GS_SALA where id_sala = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, idSala);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        }finally {
            closeConnection();
        }
        return false;
    }

    public SalaTO update(SalaTO sala) {
        String sql = "update T_GS_SALA set tipo=?, localizacao=?,consumo_energia=? where id_sala=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, sala.getTipo());
            ps.setString(2, sala.getLocalizacao());
            ps.setDouble(3, sala.getConsumoEnergia());
            ps.setLong(4, sala.getIdSala());
            if (ps.executeUpdate() > 0) {
                return sala;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}

