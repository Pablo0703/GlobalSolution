package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

public class TemperaturaAmbienteTO {
    private Long idTemperatura;
    @NotNull
    private Double temperatura;
    @NotNull
    private LocalDateTime dataHora;
    private Long idSala;
    private Long idClinica;
    @NotBlank
    private String status;

    public TemperaturaAmbienteTO() {
    }

    public TemperaturaAmbienteTO(Long idTemperatura, @NotNull Double temperatura, @NotNull LocalDateTime dataHora, Long idSala, Long idClinica, @NotBlank String status) {
        this.idTemperatura = idTemperatura;
        this.temperatura = temperatura;
        this.dataHora = dataHora;
        this.idSala = idSala;
        this.idClinica = idClinica;
        this.status = status;
    }

    public Long getIdTemperatura() {
        return idTemperatura;
    }

    public void setIdTemperatura(Long idTemperatura) {
        this.idTemperatura = idTemperatura;
    }

    public Double getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(Double temperatura) {
        this.temperatura = temperatura;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public Long getIdSala() {
        return idSala;
    }

    public void setIdSala(Long idSala) {
        this.idSala = idSala;
    }

    public Long getIdClinica() {
        return idClinica;
    }

    public void setIdClinica(Long idClinica) {
        this.idClinica = idClinica;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

