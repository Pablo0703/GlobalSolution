package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class EquipamentoTO {
    private Long idEquipamento;
    private Long idSala;
    @NotBlank
    private String tipoEquipamento;
    @NotNull
    private double consumoEstimado;
    @NotBlank
    private String status;

    public EquipamentoTO() {
    }

    public EquipamentoTO(Long idEquipamento, Long idSala, @NotBlank String tipoEquipamento,@NotNull double consumoEstimado,@NotBlank String status) {
        this.idEquipamento = idEquipamento;
        this.idSala = idSala;
        this.tipoEquipamento = tipoEquipamento;
        this.consumoEstimado = consumoEstimado;
        this.status = status;
    }

    public Long getIdEquipamento() {
        return idEquipamento;
    }

    public void setIdEquipamento(Long idEquipamento) {
        this.idEquipamento = idEquipamento;
    }

    public Long getIdSala() {
        return idSala;
    }

    public void setIdSala(Long idSala) {
        this.idSala = idSala;
    }

    public String getTipoEquipamento() {
        return tipoEquipamento;
    }

    public void setTipoEquipamento(String tipoEquipamento) {
        this.tipoEquipamento = tipoEquipamento;
    }

    public double getConsumoEstimado() {
        return consumoEstimado;
    }

    public void setConsumoEstimado(double consumoEstimado) {
        this.consumoEstimado = consumoEstimado;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
