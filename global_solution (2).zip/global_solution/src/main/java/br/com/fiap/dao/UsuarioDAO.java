package br.com.fiap.dao;

import br.com.fiap.to.UsuarioTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class UsuarioDAO extends Repository {

    public ArrayList<UsuarioTO> findAll() {
        ArrayList<UsuarioTO> usuarios = new ArrayList<UsuarioTO>();
        String sql = "SELECT * FROM T_GS_USUARIO order by id_usuario";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    UsuarioTO usuario = new UsuarioTO();
                    usuario.setIdUsuario(rs.getLong("id_usuario"));
                    usuario.setNome(rs.getString("nome"));
                    usuario.setEmail(rs.getString("email"));
                    usuario.setTipoUsuario(rs.getString("tipo_usuario"));
                    usuario.setSenha(rs.getString("senha"));
                    usuario.setDataCriacao(rs.getTimestamp("data_criacao").toLocalDateTime());
                    usuario.setStatus(rs.getString("status"));
                    usuarios.add(usuario);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return usuarios;
    }

    public UsuarioTO findById(Long idUsuario) {
        UsuarioTO usuario = new UsuarioTO();
        String sql = "SELECT * FROM T_GS_USUARIO WHERE id_usuario = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idUsuario);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
                usuario.setIdUsuario(rs.getLong("id_usuario"));
                usuario.setNome(rs.getString("nome"));
                usuario.setEmail(rs.getString("email"));
                usuario.setTipoUsuario(rs.getString("tipo_usuario"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setDataCriacao(rs.getTimestamp("data_criacao").toLocalDateTime());
                usuario.setStatus(rs.getString("status"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return usuario;
    }

    public UsuarioTO save(UsuarioTO usuario) {
        String sql = "INSERT INTO T_GS_USUARIO (nome, email, tipo_usuario, senha, data_criacao, status) VALUES(?,?,?,?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getTipoUsuario());
            ps.setString(4, usuario.getSenha());
            ps.setTimestamp(5, Timestamp.valueOf(usuario.getDataCriacao()));
            ps.setString(6, usuario.getStatus());
            if (ps.executeUpdate() > 0) {
                return usuario;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long idUsuario) {
        String sql = "DELETE FROM T_GS_USUARIO WHERE id_usuario = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, idUsuario);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public UsuarioTO update(UsuarioTO usuario) {
        String sql = "UPDATE T_GS_USUARIO SET nome=?, email=?, tipo_usuario=?, senha=?, data_criacao=?, status=? WHERE id_usuario=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getTipoUsuario());
            ps.setString(4, usuario.getSenha());
            ps.setTimestamp(5, Timestamp.valueOf(usuario.getDataCriacao()));
            ps.setString(6, usuario.getStatus());
            ps.setLong(7, usuario.getIdUsuario());
            if (ps.executeUpdate() > 0) {
                return usuario;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}

