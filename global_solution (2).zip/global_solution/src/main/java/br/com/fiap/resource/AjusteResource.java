package br.com.fiap.resource;

import br.com.fiap.bo.AjusteBO;
import br.com.fiap.to.AjusteTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;

@Path("/globalSolution/ajuste")
public class AjusteResource {
    private AjusteBO ajusteBO = new AjusteBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll() {
        ArrayList<AjusteTO> lista = ajusteBO.findAll();
        Response.ResponseBuilder response = null;
        if (lista != null) {
            response = Response.ok(200);
        } else {
            response = Response.status(404);
        }
        response.entity(lista);
        return response.build();
    }
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findById(@PathParam("id") Long idAjuste) {
        AjusteTO resultado = ajusteBO.findById(idAjuste);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response save(@Valid AjusteTO ajuste) {
        AjusteTO resultado = ajusteBO.save(ajuste);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(null);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @DELETE
    @Path("{id}")
    public Response delete(@PathParam("id") Long idAjuste) {
        Response.ResponseBuilder response = null;
        if (ajusteBO.delete(idAjuste)) {
            response = Response.ok(204);
        } else{
            response = Response.status(404);
        }
        return response.build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response update(@Valid AjusteTO ajuste, @PathParam("id") Long idAjuste) {
        ajuste.setIdAjuste(idAjuste);
        AjusteTO resultado = ajusteBO.update(ajuste);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(null);
        }else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }
}
