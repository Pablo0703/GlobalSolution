package br.com.fiap.bo;

import br.com.fiap.dao.EnergiaRecomendadaDAO;
import br.com.fiap.to.EnergiaRecomendadaTO;

import java.util.ArrayList;

public class EnergiaRecomendadaBO {
    private EnergiaRecomendadaDAO energiaRecomendadaDAO;

    public ArrayList<EnergiaRecomendadaTO> findAll() {
        energiaRecomendadaDAO = new EnergiaRecomendadaDAO();
        // Aqui pode ser aplicada alguma regra de negócio
        return energiaRecomendadaDAO.findAll();
    }

    public EnergiaRecomendadaTO findById(Long idRecomendacao) {
        energiaRecomendadaDAO = new EnergiaRecomendadaDAO();
        // Regras de negócio específicas, se houver
        return energiaRecomendadaDAO.findById(idRecomendacao);
    }

    public EnergiaRecomendadaTO save(EnergiaRecomendadaTO recomendacao) {
        energiaRecomendadaDAO = new EnergiaRecomendadaDAO();
        // Aqui pode ser aplicada alguma regra de negócio
        return energiaRecomendadaDAO.save(recomendacao);
    }

    public boolean delete(Long idRecomendacao) {
        energiaRecomendadaDAO = new EnergiaRecomendadaDAO();
        // Regras de negócio específicas, se houver
        return energiaRecomendadaDAO.delete(idRecomendacao);
    }

    public EnergiaRecomendadaTO update(EnergiaRecomendadaTO recomendacao) {
        energiaRecomendadaDAO = new EnergiaRecomendadaDAO();
        // Regras de negócio específicas, se houver
        return energiaRecomendadaDAO.update(recomendacao);
    }
}

