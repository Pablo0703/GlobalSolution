package br.com.fiap.resource;

import br.com.fiap.bo.ConsumoBO;
import br.com.fiap.to.ConsumoTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;

@Path("/globalSolution/consumo")
public class ConsumoResource {
    private ConsumoBO consumoBO = new ConsumoBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll() {
        ArrayList<ConsumoTO> resultado = consumoBO.findAll();
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(resultado);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findById(@PathParam("id") Long id) {
        ConsumoTO consumo = consumoBO.findById(id);
        Response.ResponseBuilder response = null;
        if (consumo != null) {
            response = Response.ok(consumo);
        } else {
            response = Response.status(404);
        }
        response.entity(consumo);
        return response.build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response save(@Valid ConsumoTO consumo) {
        ConsumoTO resultado = consumoBO.save(consumo);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(resultado);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        Response.ResponseBuilder response = null;
        if (consumoBO.delete(id)) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        return response.build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updtae(@Valid ConsumoTO consumo, @PathParam("id") Long idConsumo) {
        consumo.setIdConsumo(idConsumo);
        ConsumoTO resultado = consumoBO.update(consumo);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(resultado);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }
}
