package br.com.fiap.dao;

import br.com.fiap.to.OcupacaoTO;

import java.sql.*;
import java.util.ArrayList;

public class OcupacaoDAO extends Repository {
    public ArrayList<OcupacaoTO> findAll() {
        ArrayList<OcupacaoTO> ocupacoes = new ArrayList<OcupacaoTO>();
        String sql = "SELECT * FROM T_GS_OCUPACAO order by id_ocupacao";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    OcupacaoTO ocupacao = new OcupacaoTO();
                    ocupacao.setIdOcupacao(rs.getLong("id_ocupacao"));
                    ocupacao.setIdSala(rs.getLong("id_sala"));
                    ocupacao.setNumeroPaciente(rs.getInt("numero_paciente"));
                    ocupacao.setNecessidade(rs.getString("necessidade"));
                    ocupacao.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
                    ocupacoes.add(ocupacao);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return ocupacoes;
    }

    public OcupacaoTO findById(Long idOcupacao) {
        OcupacaoTO ocupacao = new OcupacaoTO();
        String sql = "SELECT * FROM T_GS_OCUPACAO WHERE id_ocupacao = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idOcupacao);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
               ocupacao.setIdOcupacao(rs.getLong("id_ocupacao"));
               ocupacao.setIdSala(rs.getLong("id_sala"));
               ocupacao.setNumeroPaciente(rs.getInt("numero_paciente"));
               ocupacao.setNecessidade(rs.getString("necessidade"));
                ocupacao.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return ocupacao;
    }

    public OcupacaoTO save(OcupacaoTO ocupacao) {
        String sql = "insert into T_GS_OCUPACAO (numero_paciente, necessidade, data_hora) values(?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, ocupacao.getNumeroPaciente());
            ps.setString(2, ocupacao.getNecessidade());
            ps.setTimestamp(3, Timestamp.valueOf(ocupacao.getDataHora()));

            if (ps.executeUpdate() > 0) {
                return ocupacao;
            }
        } catch (SQLException e) {
            System.out.println("erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete (Long idOcupacao) {
        String sql = "delete from T_GS_OCUPACAO where id_ocupacao = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, idOcupacao);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        }finally {
            closeConnection();
        }
        return false;
    }

    public OcupacaoTO update(OcupacaoTO ocupacao) {
        String sql = "update T_GS_OCUPACAO set numero_paciente=?, nescessidade=?, data_hora=? where id_ocupacao=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, ocupacao.getNumeroPaciente());
            ps.setString(2, ocupacao.getNecessidade());
            ps.setTimestamp(3, Timestamp.valueOf(ocupacao.getDataHora()));
            ps.setLong(4, ocupacao.getIdOcupacao());
            if (ps.executeUpdate() > 0) {
                return ocupacao;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}