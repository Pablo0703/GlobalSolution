package br.com.fiap.to;

import jakarta.validation.constraints.*;

import java.time.LocalDateTime;

public class AlertaTO {
    private Long idAlerta;
    private Long idSala;
    @NotBlank
    private String tipoAlerta;
    @NotBlank
    private String descricao;
    @NotNull
    @FutureOrPresent
    private LocalDateTime dataHora;
    @NotBlank
    private String resolvido;

    public AlertaTO() {
    }

    public AlertaTO(Long idAlerta, Long idSala, @NotBlank String tipoAlerta,@NotBlank String descricao,@NotNull @FutureOrPresent LocalDateTime dataHora,@NotBlank String resolvido) {
        this.idAlerta = idAlerta;
        this.idSala = idSala;
        this.tipoAlerta = tipoAlerta;
        this.descricao = descricao;
        this.dataHora = dataHora;
        this.resolvido = resolvido;
    }

    public Long getIdAlerta() {
        return idAlerta;
    }

    public void setIdAlerta(Long idAlerta) {
        this.idAlerta = idAlerta;
    }

    public Long getIdSala() {
        return idSala;
    }

    public void setIdSala(Long idSala) {
        this.idSala = idSala;
    }

    public String getTipoAlerta() {
        return tipoAlerta;
    }

    public void setTipoAlerta(String tipoAlerta) {
        this.tipoAlerta = tipoAlerta;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public String getResolvido() {
        return resolvido;
    }

    public void setResolvido(String resolvido) {
        this.resolvido = resolvido;
    }
}
