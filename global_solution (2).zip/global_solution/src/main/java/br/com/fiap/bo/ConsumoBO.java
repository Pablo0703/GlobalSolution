package br.com.fiap.bo;


import br.com.fiap.dao.ConsumoDAO;
import br.com.fiap.to.ConsumoTO;


import java.util.ArrayList;

public class ConsumoBO {
    private ConsumoDAO consumoDAO;

    public ArrayList<ConsumoTO> findAll() {
        consumoDAO = new ConsumoDAO();
        //regra de negocio
        return consumoDAO.findAll();
    }

    public ConsumoTO findById(Long idConsumo) {
        consumoDAO = new ConsumoDAO();
        // regras de negocio
        return consumoDAO.findById(idConsumo);
    }

    public ConsumoTO save(ConsumoTO consumo) {
        consumoDAO = new ConsumoDAO();
        //aqui aplicaria regra de negocio
        return consumoDAO.save(consumo);
    }

    public boolean delete(Long idConsumo) {
        consumoDAO = new ConsumoDAO();
        //aqui se implementa a regra de negocios especificas
        return consumoDAO.delete(idConsumo);
    }

    public ConsumoTO update(ConsumoTO consumo) {
        consumoDAO = new ConsumoDAO();
        //regra de negocio
        return consumoDAO.update(consumo);
    }
}