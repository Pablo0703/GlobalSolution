package br.com.fiap.bo;

import br.com.fiap.dao.SalaDAO;
import br.com.fiap.to.SalaTO;

import java.util.ArrayList;

public class SalaBO {
    private SalaDAO salaDAO;

    public ArrayList<SalaTO> findAll() {
        salaDAO = new SalaDAO();
        //regra de negocio
        return salaDAO.findAll();
    }

    public SalaTO findById(Long idSala) {
        salaDAO = new SalaDAO();
        // regras de negocio
        return findById(idSala);
    }

    public SalaTO save(SalaTO sala) {
        salaDAO = new SalaDAO();
        // Verifica se o tipo de sala é válido
        if (sala.getTipo() == null || sala.getTipo().isEmpty()) {
            System.out.println("Erro: O tipo de sala não pode ser vazio.");
            return null;
        }
        // Regra 1: Se o tipo for "UTI" e o consumo de energia for abaixo de 500, gerar um alerta
        if (sala.getTipo().equalsIgnoreCase("UTI") && sala.getConsumoEnergia() < 500) {
            System.out.println("Alerta: A sala UTI tem consumo de energia muito baixo. Verifique se está funcionando corretamente.");
            return null;  // Não salva a sala
        }

        // Regra 2: Se a localização for "Andar 1" e o consumo for superior a 1000, gerar um alerta
        if (sala.getLocalizacao().equalsIgnoreCase("Andar 1") && sala.getConsumoEnergia() > 1000) {
            System.out.println("Alerta: O consumo de energia na sala do Andar 1 está muito alto. Verifique o sistema de climatização.");
        }

        // Regra 3: Se a localização for "Andar 2" e o consumo for muito baixo (menos de 100), sugerir que a sala está subutilizada
        if (sala.getLocalizacao().equalsIgnoreCase("Andar 2") && sala.getConsumoEnergia() < 100) {
            System.out.println("Sugestão: A sala no Andar 2 está com baixo consumo de energia. Verifique se está sendo subutilizada.");
        }
        return salaDAO.save(sala);
    }

    public boolean delete(Long idSala) {
        salaDAO = new SalaDAO();
        //aqui se implementa a regra de negocios especificas
        return salaDAO.delete(idSala);
    }

    public SalaTO update(SalaTO sala) {
        salaDAO = new SalaDAO();
        //regra de negocio
        return salaDAO.update(sala);
    }
}
