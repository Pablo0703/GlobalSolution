package br.com.fiap.dao;

import br.com.fiap.to.EquipamentoTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EquipamentoDAO extends Repository{
    public ArrayList<EquipamentoTO> findAll() {
        ArrayList<EquipamentoTO> equipamentos = new ArrayList<EquipamentoTO>();
        String sql = "SELECT * FROM T_GS_EQUIPAMENTO order by id_equipamento";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                   EquipamentoTO equipamento = new EquipamentoTO();
                    equipamento.setIdEquipamento(rs.getLong("id_equipamento"));
                    equipamento.setIdSala(rs.getLong("id_sala"));
                    equipamento.setTipoEquipamento(rs.getString("tipo_equipamento"));
                    equipamento.setConsumoEstimado(rs.getDouble("consumo_estimado"));
                    equipamento.setStatus(rs.getString("status"));
                    equipamentos.add(equipamento);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return equipamentos;
    }

    public EquipamentoTO findById(Long idEquipamento) {
        EquipamentoTO equipamento = new EquipamentoTO();
        String sql = "SELECT * FROM T_GS_EQUIPAMENTO WHERE id_equipamento = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idEquipamento);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
               equipamento.setIdEquipamento(rs.getLong("id_equipamento"));
               equipamento.setIdSala(rs.getLong("id_sala"));
               equipamento.setTipoEquipamento(rs.getString("tipo_equipamento"));
               equipamento.setConsumoEstimado(rs.getDouble("consumo_estimado"));
               equipamento.setStatus(rs.getString("status"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return equipamento;
    }

    public EquipamentoTO save(EquipamentoTO equipamento) {
        String sql = "insert into T_GS_EQUIPAMENTO (tipo_equipamento, consumo_estimado, status) values(?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, equipamento.getTipoEquipamento());
            ps.setDouble(2, equipamento.getConsumoEstimado());
            ps.setString(3, equipamento.getStatus());
            if (ps.executeUpdate() > 0) {
                return equipamento;
            }
        } catch (SQLException e) {
            System.out.println("erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete (Long idEquipamento) {
        String sql = "delete from T_GS_EQUIPAMENTO where id_equipamento = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, idEquipamento);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        }finally {
            closeConnection();
        }
        return false;
    }

    public EquipamentoTO update(EquipamentoTO equipamento) {
        String sql = "update T_GS_EQUIPAMENTO set tipo_equipamento=?, consumo_estimado=?, status=? where id_equipamento=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, equipamento.getTipoEquipamento());
            ps.setDouble(2, equipamento.getConsumoEstimado());
            ps.setString(3, equipamento.getStatus());
            ps.setLong(4, equipamento.getIdEquipamento());
            if (ps.executeUpdate() > 0) {
                return equipamento;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

}