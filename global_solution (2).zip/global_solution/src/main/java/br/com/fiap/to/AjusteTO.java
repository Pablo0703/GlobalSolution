package br.com.fiap.to;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class AjusteTO {
    private Long idAjuste;
    private Long idOcupacao;
    private Long idSala;
    @NotBlank
    private String recomendacao;
    @NotNull
    @FutureOrPresent
    private LocalDateTime dataHora;
    @NotBlank
    private String status;

    public AjusteTO() {
    }

    public AjusteTO(Long idAjuste, Long idOcupacao, Long idSala, @NotBlank String recomendacao,@NotNull @FutureOrPresent LocalDateTime dataHora,@NotBlank String status) {
        this.idAjuste = idAjuste;
        this.idOcupacao = idOcupacao;
        this.idSala = idSala;
        this.recomendacao = recomendacao;
        this.dataHora = dataHora;
        this.status = status;
    }

    public Long getIdAjuste() {
        return idAjuste;
    }

    public void setIdAjuste(Long idAjuste) {
        this.idAjuste = idAjuste;
    }

    public Long getIdOcupacao() {
        return idOcupacao;
    }

    public void setIdOcupacao(Long idOcupacao) {
        this.idOcupacao = idOcupacao;
    }

    public Long getIdSala() {
        return idSala;
    }

    public void setIdSala(Long idSala) {
        this.idSala = idSala;
    }

    public String getRecomendacao() {
        return recomendacao;
    }

    public void setRecomendacao(String recomendacao) {
        this.recomendacao = recomendacao;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
