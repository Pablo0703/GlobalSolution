package br.com.fiap.resource;

import br.com.fiap.bo.EquipamentoBO;
import br.com.fiap.to.EquipamentoTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;

@Path("/globalSolution/equipamento")
public class EquipamentoResource {
    private EquipamentoBO equipamentoBO = new EquipamentoBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll() {
        ArrayList<EquipamentoTO> resultado = equipamentoBO.findAll();
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findByid(@PathParam("id") Long id) {
        EquipamentoTO equipamento = equipamentoBO.findById(id);
        Response.ResponseBuilder response = null;
        if (equipamento != null) {
            response = Response.ok(equipamento);
        } else {
            response = Response.status(404);
        }
        response.entity(equipamento);
        return response.build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public  Response save(@Valid EquipamentoTO equipamento) {
        EquipamentoTO resultado = equipamentoBO.save(equipamento);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @DELETE
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") Long id) {
        Response.ResponseBuilder response = null;
        if (equipamentoBO.delete(id)) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        return response.build();
    }

    @PUT
    @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response update(@Valid EquipamentoTO equipamento, @PathParam("id") Long id) {
        equipamento.setIdEquipamento(id);
        EquipamentoTO resultado = equipamentoBO.update(equipamento);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }
}
