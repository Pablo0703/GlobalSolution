package br.com.fiap.resource;

import br.com.fiap.bo.OcupacaoBO;
import br.com.fiap.to.OcupacaoTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;

@Path("/globalSolution/ocupacao")
public class OcupacaoResource {
    private OcupacaoBO ocupacaoBO = new OcupacaoBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll() {
        ArrayList<OcupacaoTO> resultado = ocupacaoBO.findAll();
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findById(@PathParam("id") Long id) {
        OcupacaoTO ocupacao = ocupacaoBO.findById(id);
        Response.ResponseBuilder response = null;
        if (ocupacao != null) {
            response = Response.ok(ocupacao);
        } else {
            response = Response.status(404);
        }
        response.entity(ocupacao);
        return response.build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response save(@Valid OcupacaoTO ocupacao) {
        OcupacaoTO resultado = ocupacaoBO.save(ocupacao);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        Response.ResponseBuilder response = null;
        if (ocupacaoBO.delete(id)) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        return response.build();
    }

    @PUT
    @Path("/{id}")
    @Consumes
    public  Response update(@Valid OcupacaoTO ocupacao, @PathParam("id") Long id) {
        ocupacao.setIdOcupacao(id);
        OcupacaoTO resultado = ocupacaoBO.update(ocupacao);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }
}