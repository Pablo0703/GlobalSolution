package br.com.fiap.bo;

import br.com.fiap.dao.AjusteDAO;
import br.com.fiap.to.AjusteTO;

import java.util.ArrayList;

public class AjusteBO {
    private AjusteDAO ajusteDAO;

    public ArrayList<AjusteTO> findAll() {
            ajusteDAO = new AjusteDAO();
            //regra de negocio
            return ajusteDAO.findAll();
    }

    public AjusteTO findById(Long idAjuste) {
            ajusteDAO = new AjusteDAO();
            // regras de negocio
            return ajusteDAO.findById(idAjuste);
    }

    public AjusteTO save(AjusteTO ajuste) {
            ajusteDAO = new AjusteDAO();
            //aqui aplicaria regra de negocio
            return ajusteDAO.save(ajuste);
    }

    public boolean delete(Long idAjuste) {
            ajusteDAO = new AjusteDAO();
            //aqui se implementa a regra de negocios especificas
            return ajusteDAO.delete(idAjuste);
    }

    public AjusteTO update(AjusteTO ajuste) {
            ajusteDAO = new AjusteDAO();
            //regra de negocio
            return ajusteDAO.update(ajuste);
    }
}
