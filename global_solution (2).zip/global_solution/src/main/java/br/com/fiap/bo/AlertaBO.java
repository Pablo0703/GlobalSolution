package br.com.fiap.bo;

import br.com.fiap.dao.AlertaDAO;
import br.com.fiap.to.AlertaTO;

import java.util.ArrayList;

public class AlertaBO {
    private AlertaDAO alertaDAO;

    public ArrayList<AlertaTO> findAll() {
        alertaDAO = new AlertaDAO();
        //regra de negocio
        return alertaDAO.findAll();
    }

    public AlertaTO findById(Long idAlerta) {
        alertaDAO = new AlertaDAO();
        // regras de negocio
        return alertaDAO.findById(idAlerta);
    }

    public AlertaTO save(AlertaTO alerta) {
        alertaDAO = new AlertaDAO();
        //aqui aplicaria regra de negocio
        return alertaDAO.save(alerta);
    }

    public boolean delete(Long idAlerta) {
        alertaDAO = new AlertaDAO();
        //aqui se implementa a regra de negocios especificas
        return alertaDAO.delete(idAlerta);
    }

    public AlertaTO update(AlertaTO alerta) {
        alertaDAO = new AlertaDAO();
        //regra de negocio
        return alertaDAO.update(alerta);
    }
}