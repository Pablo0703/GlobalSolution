package br.com.fiap.bo;

import br.com.fiap.dao.OcupacaoDAO;
import br.com.fiap.to.OcupacaoTO;

import java.util.ArrayList;

public class OcupacaoBO {
    private OcupacaoDAO ocupacaoDAO;

    public ArrayList<OcupacaoTO> findAll() {
        ocupacaoDAO = new OcupacaoDAO();
        //regra de negocio
        return ocupacaoDAO.findAll();
    }

    public OcupacaoTO findById(Long idOcupacao) {
        ocupacaoDAO = new OcupacaoDAO();
        // regras de negocio
        return findById(idOcupacao);
    }

    public OcupacaoTO save(OcupacaoTO ocupacaoTO) {
        ocupacaoDAO = new OcupacaoDAO();
        //aqui aplicaria regra de negocio
        return ocupacaoDAO.save(ocupacaoTO);
    }

    public boolean delete(Long idOcupacao) {
        ocupacaoDAO = new OcupacaoDAO();
        //aqui se implementa a regra de negocios especificas
        return ocupacaoDAO.delete(idOcupacao);
    }

    public OcupacaoTO update(OcupacaoTO ocupacaoTO) {
        ocupacaoDAO = new OcupacaoDAO();
        //regra de negocio
        return ocupacaoDAO.update(ocupacaoTO);
    }
}