package br.com.fiap.bo;

import br.com.fiap.dao.TemperaturaAmbienteDAO;
import br.com.fiap.to.TemperaturaAmbienteTO;

import java.util.ArrayList;

public class TemperaturaAmbienteBO {
    private TemperaturaAmbienteDAO temperaturaAmbienteDAO;

    public ArrayList<TemperaturaAmbienteTO> findAll() {
        temperaturaAmbienteDAO = new TemperaturaAmbienteDAO();
        // Aqui pode ser aplicada alguma regra de negócio
        return temperaturaAmbienteDAO.findAll();
    }

    public TemperaturaAmbienteTO findById(Long idTemperatura) {
        temperaturaAmbienteDAO = new TemperaturaAmbienteDAO();
        // Regras de negócio específicas, se houver
        return temperaturaAmbienteDAO.findById(idTemperatura);
    }

    public TemperaturaAmbienteTO save(TemperaturaAmbienteTO temperatura) {
        temperaturaAmbienteDAO = new TemperaturaAmbienteDAO();

        // Regra 1: A temperatura não pode ser negativa
        if (temperatura.getTemperatura() < 0) {
            System.out.println("Erro: A temperatura ambiente não pode ser negativa.");
            return null;
        }

        // Regra 2: Se a temperatura for maior que 35°C, gerar um alerta de superaquecimento
        if (temperatura.getTemperatura() > 35) {
            System.out.println("Alerta: Temperatura elevada registrada! Verifique os sistemas de climatização.");
        }

        // Regra 3: Se a temperatura estiver abaixo de 15°C, sugerir verificar o aquecimento
        if (temperatura.getTemperatura() < 15) {
            System.out.println("Sugestão: Temperatura baixa detectada. Verifique o sistema de aquecimento.");
        }

        return temperaturaAmbienteDAO.save(temperatura);
    }

    public boolean delete(Long idTemperatura) {
        temperaturaAmbienteDAO = new TemperaturaAmbienteDAO();
        // Aqui se podem implementar regras específicas antes da exclusão
        return temperaturaAmbienteDAO.delete(idTemperatura);
    }

    public TemperaturaAmbienteTO update(TemperaturaAmbienteTO temperatura) {
        temperaturaAmbienteDAO = new TemperaturaAmbienteDAO();

        // Regra 1: A temperatura não pode ser negativa
        if (temperatura.getTemperatura() < 0) {
            System.out.println("Erro: A temperatura ambiente não pode ser negativa.");
            return null;
        }

        // Reaplicando as outras regras ao atualizar
        if (temperatura.getTemperatura() > 35) {
            System.out.println("Alerta: Temperatura elevada registrada! Verifique os sistemas de climatização.");
        }

        if (temperatura.getTemperatura() < 15) {
            System.out.println("Sugestão: Temperatura baixa detectada. Verifique o sistema de aquecimento.");
        }

        return temperaturaAmbienteDAO.update(temperatura);
    }
}
