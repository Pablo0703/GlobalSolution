package br.com.fiap.dao;

import br.com.fiap.to.TemperaturaAmbienteTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class TemperaturaAmbienteDAO extends Repository {

    public ArrayList<TemperaturaAmbienteTO> findAll() {
        ArrayList<TemperaturaAmbienteTO> temperaturas = new ArrayList<TemperaturaAmbienteTO>();
        String sql = "SELECT * FROM T_GS_TEMPERATURA_AMBIENTE order by id_temperatura";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    TemperaturaAmbienteTO temperatura = new TemperaturaAmbienteTO();
                    temperatura.setIdTemperatura(rs.getLong("id_temperatura"));
                    temperatura.setIdSala(rs.getLong("id_sala"));
                    temperatura.setTemperatura(rs.getDouble("temperatura"));
                    temperatura.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
                    temperatura.setStatus(rs.getString("status"));
                    temperaturas.add(temperatura);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return temperaturas;
    }

    public TemperaturaAmbienteTO findById(Long idTemperatura) {
        TemperaturaAmbienteTO temperatura = new TemperaturaAmbienteTO();
        String sql = "SELECT * FROM T_GS_TEMPERATURA_AMBIENTE WHERE id_temperatura = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idTemperatura);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
                temperatura.setIdTemperatura(rs.getLong("id_temperatura"));
                temperatura.setIdSala(rs.getLong("id_sala"));
                temperatura.setTemperatura(rs.getDouble("temperatura"));
                temperatura.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
                temperatura.setStatus(rs.getString("status"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return temperatura;
    }

    public TemperaturaAmbienteTO save(TemperaturaAmbienteTO temperatura) {
        String sql = "INSERT INTO T_GS_TEMPERATURA_AMBIENTE (temperatura, data_hora, status) VALUES(?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setDouble(1, temperatura.getTemperatura());
            ps.setTimestamp(2, Timestamp.valueOf(temperatura.getDataHora()));
            ps.setString(3, temperatura.getStatus());
            if (ps.executeUpdate() > 0) {
                return temperatura;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long idTemperatura) {
        String sql = "DELETE FROM T_GS_TEMPERATURA_AMBIENTE WHERE id_temperatura = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, idTemperatura);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public TemperaturaAmbienteTO update(TemperaturaAmbienteTO temperatura) {
        String sql = "UPDATE T_GS_TEMPERATURA_AMBIENTE SET temperatura=?, data_hora=?, status=? WHERE id_temperatura=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setDouble(1, temperatura.getTemperatura());
            ps.setTimestamp(2, Timestamp.valueOf(temperatura.getDataHora()));
            ps.setString(3, temperatura.getStatus());
            ps.setLong(4, temperatura.getIdTemperatura());
            if (ps.executeUpdate() > 0) {
                return temperatura;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
