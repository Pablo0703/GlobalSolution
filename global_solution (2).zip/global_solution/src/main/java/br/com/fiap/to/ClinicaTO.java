package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;

public class ClinicaTO {
    private Long idClinica;

    @NotBlank
    private String nome;     // Nome da clínica
    @NotBlank
    private String endereco; // Endereço da clínica (opcional)

    public ClinicaTO() {
    }

    public ClinicaTO(Long idClinica, @NotBlank String nome, @NotBlank String endereco) {
        this.idClinica = idClinica;
        this.nome = nome;
        this.endereco = endereco;
    }

    public Long getIdClinica() {
        return idClinica;
    }

    public void setIdClinica(Long idClinica) {
        this.idClinica = idClinica;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
}

