package br.com.fiap.bo;

import br.com.fiap.dao.UsuarioDAO;
import br.com.fiap.to.UsuarioTO;

import java.util.ArrayList;

public class UsuarioBO {
    private UsuarioDAO usuarioDAO;

    public ArrayList<UsuarioTO> findAll() {
        usuarioDAO = new UsuarioDAO();
        // Aqui pode ser aplicada alguma regra de negócio
        return usuarioDAO.findAll();
    }

    public UsuarioTO findById(Long idUsuario) {
        usuarioDAO = new UsuarioDAO();
        // Regras de negócio específicas, se houver
        return usuarioDAO.findById(idUsuario);
    }

    public UsuarioTO save(UsuarioTO usuario) {
        usuarioDAO = new UsuarioDAO();
        // Aqui pode ser aplicada alguma regra de negócio
        return usuarioDAO.save(usuario);
    }

    public boolean delete(Long idUsuario) {
        usuarioDAO = new UsuarioDAO();
        // Regras de negócio específicas, se houver
        return usuarioDAO.delete(idUsuario);
    }

    public UsuarioTO update(UsuarioTO usuario) {
        usuarioDAO = new UsuarioDAO();
        // Regras de negócio específicas, se houver
        return usuarioDAO.update(usuario);
    }
}

