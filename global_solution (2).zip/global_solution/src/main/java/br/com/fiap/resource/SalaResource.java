package br.com.fiap.resource;

import br.com.fiap.bo.SalaBO;
import br.com.fiap.to.SalaTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import oracle.jdbc.proxy.annotation.Post;

import java.util.ArrayList;

@Path("/globalSolution/sala")
public class SalaResource {
    private SalaBO salaBO = new SalaBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll() {
        ArrayList<SalaTO> resultado = salaBO.findAll();
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(resultado);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findById(@PathParam("id") Long id) {
        SalaTO resultado = salaBO.findById(id);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(resultado);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response save(@Valid SalaTO sala) {
        SalaTO resultado = salaBO.save(sala);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(resultado);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        Response.ResponseBuilder response = null;
        if (salaBO.delete(id)) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        return response.build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response update(@Valid SalaTO sala, @PathParam("id") Long id) {
        sala.setIdSala(id);
        SalaTO resultado = salaBO.update(sala);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(resultado);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }
}