package br.com.fiap.dao;

import br.com.fiap.to.EnergiaRecomendadaTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class EnergiaRecomendadaDAO extends Repository {

    public ArrayList<EnergiaRecomendadaTO> findAll() {
        ArrayList<EnergiaRecomendadaTO> recomendacoes = new ArrayList<EnergiaRecomendadaTO>();
        String sql = "SELECT * FROM T_GS_ENERGIA_RECOMENDADA order by id_recomendacao";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    EnergiaRecomendadaTO recomendacao = new EnergiaRecomendadaTO();
                    recomendacao.setIdRecomendacao(rs.getLong("id_recomendacao"));
                    recomendacao.setIdSala(rs.getLong("id_sala"));
                    recomendacao.setIdClinica(rs.getLong("id_clinica"));
                    recomendacao.setDescricao(rs.getString("descricao"));
                    recomendacao.setTipoRecomendacao(rs.getString("tipo_recomendacao"));
                    recomendacao.setDataRecomendacao(rs.getTimestamp("data_recomendacao").toLocalDateTime());
                    recomendacao.setStatus(rs.getString("status"));
                    recomendacoes.add(recomendacao);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return recomendacoes;
    }

    public EnergiaRecomendadaTO findById(Long idRecomendacao) {
        EnergiaRecomendadaTO recomendacao = new EnergiaRecomendadaTO();
        String sql = "SELECT * FROM T_GS_ENERGIA_RECOMENDADA WHERE id_recomendacao = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idRecomendacao);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
                recomendacao.setIdRecomendacao(rs.getLong("id_recomendacao"));
                recomendacao.setIdSala(rs.getLong("id_sala"));
                recomendacao.setIdClinica(rs.getLong("id_clinica"));
                recomendacao.setDescricao(rs.getString("descricao"));
                recomendacao.setTipoRecomendacao(rs.getString("tipo_recomendacao"));
                recomendacao.setDataRecomendacao(rs.getTimestamp("data_recomendacao").toLocalDateTime());
                recomendacao.setStatus(rs.getString("status"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return recomendacao;
    }

    public EnergiaRecomendadaTO save(EnergiaRecomendadaTO recomendacao) {
        String sql = "INSERT INTO T_GS_ENERGIA_RECOMENDADA (descricao, tipo_recomendacao, data_recomendacao, status) VALUES(?,?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, recomendacao.getDescricao());
            ps.setString(2, recomendacao.getTipoRecomendacao());
            ps.setTimestamp(3, Timestamp.valueOf(recomendacao.getDataRecomendacao()));
            ps.setString(4, recomendacao.getStatus());
            if (ps.executeUpdate() > 0) {
                return recomendacao;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long idRecomendacao) {
        String sql = "DELETE FROM T_GS_ENERGIA_RECOMENDADA WHERE id_recomendacao = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, idRecomendacao);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public EnergiaRecomendadaTO update(EnergiaRecomendadaTO recomendacao) {
        String sql = "UPDATE T_GS_ENERGIA_RECOMENDADA SET descricao=?, tipo_recomendacao=?, data_recomendacao=?, status=? WHERE id_recomendacao=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, recomendacao.getDescricao());
            ps.setString(2, recomendacao.getTipoRecomendacao());
            ps.setTimestamp(3, Timestamp.valueOf(recomendacao.getDataRecomendacao()));
            ps.setString(4, recomendacao.getStatus());
            ps.setLong(5, recomendacao.getIdRecomendacao());
            if (ps.executeUpdate() > 0) {
                return recomendacao;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}

