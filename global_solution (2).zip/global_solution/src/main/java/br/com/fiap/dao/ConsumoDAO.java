package br.com.fiap.dao;



import br.com.fiap.to.ConsumoTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class ConsumoDAO extends Repository {public ArrayList<ConsumoTO> findAll() {
    ArrayList<ConsumoTO> consumos = new ArrayList<ConsumoTO>();
    String sql = "SELECT * FROM T_GS_CONSUMO order by id_consumo";
    try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
        ResultSet rs = ps.executeQuery();
        if (rs != null) {
            while (rs.next()) {
                ConsumoTO consumo = new ConsumoTO();
                consumo.setIdConsumo(rs.getLong("id_consumo"));
                consumo.setIdSala(rs.getLong("id_sala"));
                consumo.setConsumoEnergia(rs.getDouble("consumo_energia"));
                consumo.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
                consumos.add(consumo);
            }
        } else {
            return null;
        }
    } catch (SQLException e) {
        System.out.println("Erro na consulta: " + e.getMessage());
    } finally {
        closeConnection();
    }
    return consumos;
}

    public ConsumoTO findById(Long idConsumo) {
        ConsumoTO consumo = new ConsumoTO();
        String sql = "SELECT * FROM T_GS_CONSUMO WHERE id_consumo = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idConsumo);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
               consumo.setIdConsumo(rs.getLong("id_consumo"));
               consumo.setIdSala(rs.getLong("id_sala"));
               consumo.setConsumoEnergia(rs.getDouble("consumo_energia"));
               consumo.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return consumo;
    }

    public ConsumoTO save(ConsumoTO consumo) {
        String sql = "insert into T_GS_CONSUMO (consumo_energia, data_hora) values(?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setDouble(1, consumo.getConsumoEnergia());
            ps.setTimestamp(2, Timestamp.valueOf(consumo.getDataHora()));
            if (ps.executeUpdate() > 0) {
                return consumo;
            }
        } catch (SQLException e) {
            System.out.println("erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete (Long idEquipamento) {
        String sql = "delete from T_GS_EQUIPAMENTO where id_equipamento = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, idEquipamento);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        }finally {
            closeConnection();
        }
        return false;
    }

    public ConsumoTO update(ConsumoTO consumo) {
        String sql = "update T_GS_CONSUMO set data_hora=?,consumo_energia=? where id_consumo=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setTimestamp(1, Timestamp.valueOf(consumo.getDataHora()));
            ps.setDouble(2, consumo.getConsumoEnergia());
            ps.setLong(3, consumo.getIdConsumo());
            if (ps.executeUpdate() > 0) {
                return consumo;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}