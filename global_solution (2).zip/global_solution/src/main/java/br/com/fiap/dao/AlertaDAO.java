package br.com.fiap.dao;

import br.com.fiap.to.AlertaTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class AlertaDAO extends Repository {
    public ArrayList<AlertaTO> findAll() {
    ArrayList<AlertaTO> alertas = new ArrayList<AlertaTO>();
    String sql = "SELECT * FROM T_GS_ALERTA order by id_alerta";
    try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
        ResultSet rs = ps.executeQuery();
        if (rs != null) {
            while (rs.next()) {
               AlertaTO alerta = new AlertaTO();
           alerta.setIdAlerta(rs.getLong("id_alerta"));
           alerta.setIdSala(rs.getLong("id_sala"));
           alerta.setTipoAlerta(rs.getString("tipo_alerta"));
           alerta.setDescricao(rs.getString("descricao"));
           alerta.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
           alerta.setResolvido(rs.getString("resolvido"));
           alertas.add(alerta);
            }
        } else {
            return null;
        }
    } catch (SQLException e) {
        System.out.println("Erro na consulta: " + e.getMessage());
    } finally {
        closeConnection();
    }
    return alertas;
}

    public AlertaTO findById(Long idAlerta) {
        AlertaTO alerta = new AlertaTO();
        String sql = "SELECT * FROM T_GS_ALERTA WHERE id_alerta = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idAlerta);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
               alerta.setIdAlerta(rs.getLong("id_alerta"));
               alerta.setIdSala(rs.getLong("id_sala"));
               alerta.setTipoAlerta(rs.getString("tipo_alerta"));
               alerta.setDescricao(rs.getString("descricao"));
               alerta.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
               alerta.setResolvido(rs.getString("resolvido"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return alerta;
    }

    public AlertaTO save(AlertaTO alerta) {
        String sql = "insert into T_GS_ALERTA (tipo_alerta, descricao, data_hora, resolvido) values(?,?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
           ps.setString(1, alerta.getTipoAlerta());
           ps.setString(2, alerta.getDescricao());
            ps.setTimestamp(3, Timestamp.valueOf(alerta.getDataHora()));
            ps.setString(4, alerta.getResolvido());
            if (ps.executeUpdate() > 0) {
                return alerta;
            }
        } catch (SQLException e) {
            System.out.println("erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete (Long idAlerta) {
        String sql = "delete from T_GS_ALERTA where id_alerta = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, idAlerta);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        }finally {
            closeConnection();
        }
        return false;
    }

    public AlertaTO update(AlertaTO alerta) {
        String sql = "update T_GS_ALERTA set tipo_alerta=?, descricao=?, data_hora=?, resolvido=? where id_alerta=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
          ps.setString(1, alerta.getTipoAlerta());
          ps.setString(2, alerta.getDescricao());
          ps.setTimestamp(3, Timestamp.valueOf(alerta.getDataHora()));
          ps.setString(4, alerta.getResolvido());
          ps.setLong(5, alerta.getIdAlerta());
          if (ps.executeUpdate() > 0) {
                return alerta;
          } else {
              return null;
          }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}