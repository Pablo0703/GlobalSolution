package br.com.fiap.bo;

import br.com.fiap.dao.ClinicaDAO;
import br.com.fiap.to.ClinicaTO;

import java.util.ArrayList;

public class ClinicaBO {
    private ClinicaDAO clinicaDAO;

    public ArrayList<ClinicaTO> findAll() {
        clinicaDAO = new ClinicaDAO();
        //regra de negocio
        return clinicaDAO.findAll();
    }

    public ClinicaTO findById(Long idClinica) {
        clinicaDAO = new ClinicaDAO();
        // regras de negocio
        return clinicaDAO.findById(idClinica);
    }

    public ClinicaTO save(ClinicaTO clinica) {
        clinicaDAO = new ClinicaDAO();
        //aqui aplicaria regra de negocio
        return clinicaDAO.save(clinica);
    }

    public boolean delete(Long idClinica) {
        clinicaDAO = new ClinicaDAO();
        //aqui se implementa a regra de negocios especificas
        return clinicaDAO.delete(idClinica);
    }

    public ClinicaTO update(ClinicaTO clinica) {
        clinicaDAO = new ClinicaDAO();
        //regra de negocio
        return clinicaDAO.update(clinica);
    }
}