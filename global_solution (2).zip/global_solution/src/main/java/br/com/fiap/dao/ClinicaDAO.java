package br.com.fiap.dao;

import br.com.fiap.to.ClinicaTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClinicaDAO extends Repository {

    public ArrayList<ClinicaTO> findAll() {
        ArrayList<ClinicaTO> clinicas = new ArrayList<>();
        String sql = "SELECT * FROM T_GS_CLINICA order by id_clinica";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    ClinicaTO clinica = new ClinicaTO();
                    clinica.setIdClinica(rs.getLong("id_clinica"));
                    clinica.setNome(rs.getString("nome"));
                    clinica.setEndereco(rs.getString("endereco"));
                    clinicas.add(clinica);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return clinicas;
    }

    public ClinicaTO findById(Long idClinica) {
        ClinicaTO clinica = new ClinicaTO();
        String sql = "SELECT * FROM T_GS_CLINICA WHERE id_clinica = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idClinica);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
                clinica.setIdClinica(rs.getLong("id_clinica"));
                clinica.setNome(rs.getString("nome"));
                clinica.setEndereco(rs.getString("endereco"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return clinica;
    }

    public ClinicaTO save(ClinicaTO clinica) {
        String sql = "insert into T_GS_CLINICA (nome, endereco) values(?, ?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, clinica.getNome());
            ps.setString(2, clinica.getEndereco());
            if (ps.executeUpdate() > 0) {
                return clinica;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long idClinica) {
        String sql = "delete from T_GS_CLINICA where id_clinica = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idClinica);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public ClinicaTO update(ClinicaTO clinica) {
        String sql = "update T_GS_CLINICA set nome=?, endereco=? where id_clinica=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, clinica.getNome());
            ps.setString(2, clinica.getEndereco());
            ps.setLong(3, clinica.getIdClinica());
            if (ps.executeUpdate() > 0) {
                return clinica;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
