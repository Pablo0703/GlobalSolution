package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


import java.time.LocalDateTime;

public class EnergiaRecomendadaTO {
    private Long idRecomendacao;
    private Long idSala;
    private Long idClinica;
    @NotBlank
    private String descricao;
    @NotBlank
    private String tipoRecomendacao;
    @NotNull
    private LocalDateTime dataRecomendacao;
    @NotBlank
    private String status;

    public EnergiaRecomendadaTO() {
    }

    public EnergiaRecomendadaTO(Long idRecomendacao, Long idSala, Long idClinica, @NotBlank String descricao, @NotBlank String tipoRecomendacao, @NotNull LocalDateTime dataRecomendacao, @NotBlank String status) {
        this.idRecomendacao = idRecomendacao;
        this.idSala = idSala;
        this.idClinica = idClinica;
        this.descricao = descricao;
        this.tipoRecomendacao = tipoRecomendacao;
        this.dataRecomendacao = dataRecomendacao;
        this.status = status;
    }

    public Long getIdRecomendacao() {
        return idRecomendacao;
    }

    public void setIdRecomendacao(Long idRecomendacao) {
        this.idRecomendacao = idRecomendacao;
    }

    public Long getIdSala() {
        return idSala;
    }

    public void setIdSala(Long idSala) {
        this.idSala = idSala;
    }

    public Long getIdClinica() {
        return idClinica;
    }

    public void setIdClinica(Long idClinica) {
        this.idClinica = idClinica;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipoRecomendacao() {
        return tipoRecomendacao;
    }

    public void setTipoRecomendacao(String tipoRecomendacao) {
        this.tipoRecomendacao = tipoRecomendacao;
    }

    public LocalDateTime getDataRecomendacao() {
        return dataRecomendacao;
    }

    public void setDataRecomendacao(LocalDateTime dataRecomendacao) {
        this.dataRecomendacao = dataRecomendacao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

