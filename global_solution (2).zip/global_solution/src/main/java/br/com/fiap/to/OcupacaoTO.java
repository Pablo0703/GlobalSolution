package br.com.fiap.to;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;

import java.time.LocalDateTime;

public class OcupacaoTO {
    private Long idOcupacao;
    private Long idSala;
    @NotNull
    private int numeroPaciente;
    @NotBlank
    private String necessidade;
    @NotNull
    @FutureOrPresent
    private LocalDateTime dataHora;

    public OcupacaoTO() {
    }

    public OcupacaoTO(Long idOcupacao, Long idSala,@NotNull int numeroPaciente,@NotBlank String necessidade,@NotNull @FutureOrPresent LocalDateTime dataHora) {
        this.idOcupacao = idOcupacao;
        this.idSala = idSala;
        this.numeroPaciente = numeroPaciente;
        this.necessidade = necessidade;
        this.dataHora = dataHora;
    }

    public Long getIdOcupacao() {
        return idOcupacao;
    }

    public void setIdOcupacao(Long idOcupacao) {
        this.idOcupacao = idOcupacao;
    }

    public Long getIdSala() {
        return idSala;
    }

    public void setIdSala(Long idSala) {
        this.idSala = idSala;
    }

    public int getNumeroPaciente() {
        return numeroPaciente;
    }

    public void setNumeroPaciente(int numeroPaciente) {
        this.numeroPaciente = numeroPaciente;
    }

    public String getNecessidade() {
        return necessidade;
    }

    public void setNecessidade(String necessidade) {
        this.necessidade = necessidade;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }
}
