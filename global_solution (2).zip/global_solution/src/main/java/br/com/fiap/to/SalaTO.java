package br.com.fiap.to;

import jakarta.validation.constraints.NotBlank;

public class SalaTO {
    private Long idSala;
    @NotBlank
    private String tipo;
    @NotBlank
    private String localizacao;
    private  double consumoEnergia;

    public SalaTO() {
    }

    public SalaTO(Long idSala,@NotBlank String tipo,@NotBlank String localizacao, double consumoEnergia) {
        this.idSala = idSala;
        this.tipo = tipo;
        this.localizacao = localizacao;
        this.consumoEnergia = consumoEnergia;
    }

    public Long getIdSala() {
        return idSala;
    }

    public void setIdSala(Long idSala) {
        this.idSala = idSala;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public double getConsumoEnergia() {
        return consumoEnergia;
    }

    public void setConsumoEnergia(double consumoEnergia) {
        this.consumoEnergia = consumoEnergia;
    }
}
