package br.com.fiap.bo;

import br.com.fiap.dao.EquipamentoDAO;
import br.com.fiap.to.EquipamentoTO;

import java.util.ArrayList;

public class EquipamentoBO {
    private EquipamentoDAO equipamentoDAO;

    public ArrayList<EquipamentoTO> findAll() {
        equipamentoDAO = new EquipamentoDAO();
        return equipamentoDAO.findAll();
    }

    public EquipamentoTO findById(Long idEquipamento) {
        equipamentoDAO = new EquipamentoDAO();
        return equipamentoDAO.findById(idEquipamento);
    }

    public EquipamentoTO save(EquipamentoTO equipamento) {
        equipamentoDAO = new EquipamentoDAO();
        return equipamentoDAO.save(equipamento);
    }

    public boolean delete(Long idEquipamento) {
        equipamentoDAO = new EquipamentoDAO();
        return equipamentoDAO.delete(idEquipamento);
    }

    public EquipamentoTO update(EquipamentoTO equipamento) {
        equipamentoDAO = new EquipamentoDAO();

        return equipamentoDAO.update(equipamento);
    }

}