package br.com.fiap.resource;

import br.com.fiap.bo.AlertaBO;
import br.com.fiap.to.AlertaTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;

@Path("/globalSolution/alerta")
public class AlertaResource {
    private AlertaBO alertaBO = new AlertaBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll() {
        ArrayList<AlertaTO> resultado = alertaBO.findAll();
        Response.ResponseBuilder response = null;
        if( resultado != null) {
            response = Response.ok(resultado);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findById(@PathParam("id") Long id) {
        AlertaTO alerta = alertaBO.findById(id);
        Response.ResponseBuilder response = null;
        if( alerta != null) {
            response = Response.ok(alerta);
        } else {
            response = Response.status(404);
        }
        response.entity(alerta);
        return response.build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response save(@Valid  AlertaTO alerta) {
        AlertaTO alertaTO = alertaBO.save(alerta);
        Response.ResponseBuilder response = null;
        if( alertaTO != null) {
            response = Response.ok(null);
        } else {
            response = Response.status(404);
        }
        response.entity(alertaTO);
        return response.build();
    }

    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        Response.ResponseBuilder response = null;
        if( alertaBO.delete(id)) {
            response = Response.ok(204);
        } else {
            response = Response.status(404);
        }
        return response.build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response update(@Valid AlertaTO alerta, @PathParam("id") Long id) {
        alerta.setIdAlerta(id);
        AlertaTO alertaTO = alertaBO.update(alerta);
        Response.ResponseBuilder response = null;
        if( alertaTO != null) {
            response = Response.ok(null);
        } else {
            response = Response.status(404);
        }
        response.entity(alertaTO);
        return response.build();
    }
}
