package br.com.fiap.dao;

import br.com.fiap.to.AjusteTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class AjusteDAO extends Repository { public ArrayList<AjusteTO> findAll() {
    ArrayList<AjusteTO> ajustes = new ArrayList<AjusteTO>();
    String sql = "SELECT * FROM T_GS_AJUSTE order by id_ajuste";
    try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
        ResultSet rs = ps.executeQuery();
        if (rs != null) {
            while (rs.next()) {
                AjusteTO ajuste = new AjusteTO();
                ajuste.setIdAjuste(rs.getLong("id_ajuste"));
                ajuste.setIdOcupacao(rs.getLong("id_ocupacao"));
                ajuste.setIdSala(rs.getLong("id_sala"));
                ajuste.setRecomendacao(rs.getString("recomendacao"));
                ajuste.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
                ajuste.setStatus(rs.getString("status"));
                ajustes.add(ajuste);
            }
        } else {
            return null;
        }
    } catch (SQLException e) {
        System.out.println("Erro na consulta: " + e.getMessage());
    } finally {
        closeConnection();
    }
    return ajustes;
}

    public AjusteTO findById(Long idOcupacao) {
        AjusteTO ajuste = new AjusteTO();
        String sql = "SELECT * FROM T_GS_AJUSTE WHERE id_ajuste = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setLong(1, idOcupacao);
            ResultSet rs = ps.executeQuery();
            if (rs != null && rs.next()) {
                ajuste.setIdAjuste(rs.getLong("id_ajuste"));
                ajuste.setIdOcupacao(rs.getLong("id_ocupacao"));
                ajuste.setIdSala(rs.getLong("id_sala"));
                ajuste.setRecomendacao(rs.getString("recomendacao"));
                ajuste.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
                ajuste.setStatus(rs.getString("status"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return ajuste;
    }

    public AjusteTO save(AjusteTO ajuste) {
        String sql = "insert into T_GS_AJUSTE (recomendacao, data_hora, status) values(?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, ajuste.getRecomendacao());
            ps.setTimestamp(2, Timestamp.valueOf(ajuste.getDataHora()));
            ps.setString(3, ajuste.getStatus());
            if (ps.executeUpdate() > 0) {
                return ajuste;
            }
        } catch (SQLException e) {
            System.out.println("erro ao salvar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete (Long idAjuste) {
        String sql = "delete from T_GS_OCUPACAO where id_ajuste = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, idAjuste);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar: " + e.getMessage());
        }finally {
            closeConnection();
        }
        return false;
    }

    public AjusteTO update(AjusteTO ajuste) {
        String sql = "update T_GS_AJUSTE set recomendacao=?, data_hora=?, status=? where id_ajuste=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, ajuste.getRecomendacao());
            ps.setTimestamp(2, Timestamp.valueOf(ajuste.getDataHora()));
            ps.setString(3, ajuste.getStatus());
            ps.setLong(4, ajuste.getIdAjuste());
            if (ps.executeUpdate() > 0) {
                return ajuste;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

}