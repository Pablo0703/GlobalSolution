package br.com.fiap.resource;

import br.com.fiap.bo.EnergiaRecomendadaBO;
import br.com.fiap.to.EnergiaRecomendadaTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;

@Path("/globalSolution/energiaRecomendada")
public class EnergiaRecomendadaResource {
    private EnergiaRecomendadaBO energiaRecomendadaBO = new EnergiaRecomendadaBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll() {
        ArrayList<EnergiaRecomendadaTO> lista = energiaRecomendadaBO.findAll();
        Response.ResponseBuilder response = null;
        if (lista != null) {
            response = Response.ok(200);
        } else {
            response = Response.status(404);
        }
        response.entity(lista);
        return response.build();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findById(@PathParam("id") Long idRecomendacao) {
        EnergiaRecomendadaTO resultado = energiaRecomendadaBO.findById(idRecomendacao);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response save(@Valid EnergiaRecomendadaTO recomendacao) {
        EnergiaRecomendadaTO resultado = energiaRecomendadaBO.save(recomendacao);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(null);
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @DELETE
    @Path("{id}")
    public Response delete(@PathParam("id") Long idRecomendacao) {
        Response.ResponseBuilder response = null;
        if (energiaRecomendadaBO.delete(idRecomendacao)) {
            response = Response.ok(204);
        } else{
            response = Response.status(404);
        }
        return response.build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response update(@Valid EnergiaRecomendadaTO recomendacao, @PathParam("id") Long idRecomendacao) {
        recomendacao.setIdRecomendacao(idRecomendacao);
        EnergiaRecomendadaTO resultado = energiaRecomendadaBO.update(recomendacao);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok(null);
        }else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }
}
