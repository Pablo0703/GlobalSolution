package br.com.fiap.to;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;

import java.time.LocalDateTime;

public class ConsumoTO {
    private Long idConsumo;
    private Long idSala;
    @NotNull
    private Double consumoEnergia;
    @NotNull
    @FutureOrPresent
    private LocalDateTime dataHora;

    public ConsumoTO() {
    }

    public ConsumoTO(Long idConsumo, Long idSala, @NotNull Double consumoEnergia, @NotNull @FutureOrPresent LocalDateTime dataHora) {
        this.idConsumo = idConsumo;
        this.idSala = idSala;
        this.consumoEnergia = consumoEnergia;
        this.dataHora = dataHora;
    }

    public Long getIdConsumo() {
        return idConsumo;
    }

    public void setIdConsumo(Long idConsumo) {
        this.idConsumo = idConsumo;
    }

    public Long getIdSala() {
        return idSala;
    }

    public void setIdSala(Long idSala) {
        this.idSala = idSala;
    }

    public Double getConsumoEnergia() {
        return consumoEnergia;
    }

    public void setConsumoEnergia(Double consumoEnergia) {
        this.consumoEnergia = consumoEnergia;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }
}
